package com.sucre.cakefactory;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private GameState G;
    private Handler   handler;
    private Runnable  tickRunnable;
    private Runnable  saveRunnable;

    // UI
    private TextView tvCakes, tvTotal, tvCps, tvClickPow;
    private View     cakeBtn;
    private View     presBar;
    private TextView tvPresProgress, tvPresLevel;
    private View     btnPrestige;

    // Fragments
    private ShopFragment    shopFragment;
    private LogFragment     logFragment;
    private ClickerFragment clickerFragment;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        G = GameState.get();

        // Load saved game
        boolean loaded = G.load(this);
        G.addLog(loaded ? "💾 Прогресс загружен — добро пожаловать обратно!"
                        : "🏭 Фабрика открыта — добро пожаловать в Sucré!");
        if (!loaded) G.addLog("🎂 Подсказка: нажимай на торт, покупай постройки!");

        // Fragments
        clickerFragment = new ClickerFragment();
        shopFragment    = new ShopFragment();
        logFragment     = new LogFragment();

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragment_container, clickerFragment, "clicker")
                    .add(R.id.fragment_container, shopFragment,    "shop")
                    .add(R.id.fragment_container, logFragment,     "log")
                    .hide(shopFragment)
                    .hide(logFragment)
                    .commit();
        }

        // Bottom nav
        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_clicker) showFragment(clickerFragment);
            else if (id == R.id.nav_shop) showFragment(shopFragment);
            else if (id == R.id.nav_log)  showFragment(logFragment);
            return true;
        });

        // Game loop — tick every 50ms (20 fps)
        handler = new Handler(Looper.getMainLooper());
        tickRunnable = new Runnable() {
            private long lastTick = System.currentTimeMillis();

            @Override
            public void run() {
                long now = System.currentTimeMillis();
                double dt = (now - lastTick) / 1000.0;
                lastTick = now;

                double earned = G.calcCps() * dt;
                G.cakes      += earned;
                G.totalCakes += earned;

                // Check achievements
                GameState.Achievement ach = G.checkAchievements();
                if (ach != null) {
                    showToast(ach.icon + " Достижение: " + ach.name);
                    if (shopFragment.isVisible()) shopFragment.refreshAchievements();
                }

                // Notify active fragments
                notifyFragments();

                handler.postDelayed(this, 50);
            }
        };

        // Auto-save every 15s
        saveRunnable = new Runnable() {
            @Override
            public void run() {
                G.save(MainActivity.this);
                handler.postDelayed(this, 15_000);
            }
        };
    }

    private void showFragment(Fragment target) {
        getSupportFragmentManager().beginTransaction()
                .hide(clickerFragment)
                .hide(shopFragment)
                .hide(logFragment)
                .show(target)
                .commit();
    }

    private void notifyFragments() {
        if (clickerFragment.isVisible()) clickerFragment.refresh();
        if (shopFragment.isVisible())    shopFragment.refreshBuildings();
        if (logFragment.isVisible())     logFragment.refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(tickRunnable);
        handler.postDelayed(saveRunnable, 15_000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tickRunnable);
        handler.removeCallbacks(saveRunnable);
        G.save(this);
    }

    public void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
