package com.sucre.cakefactory;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class LogFragment extends Fragment {

    private LinearLayout logContainer;
    private ScrollView   scrollView;
    private int          lastCount = 0;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_log, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        logContainer = view.findViewById(R.id.log_container);
        scrollView   = view.findViewById(R.id.log_scroll);
        refresh();
    }

    public void refresh() {
        if (logContainer == null) return;
        GameState G = GameState.get();
        if (G.log.size() == lastCount) return;
        lastCount = G.log.size();

        logContainer.removeAllViews();
        for (String msg : G.log) {
            TextView tv = new TextView(getContext());
            tv.setText(msg);
            tv.setTextSize(14f);
            tv.setTextColor(0xFF6b4c3b);
            tv.setPadding(16, 12, 16, 12);

            // Divider-ish look via bottom padding + background
            tv.setBackgroundResource(R.drawable.log_item_bg);
            logContainer.addView(tv);
        }
    }
}
