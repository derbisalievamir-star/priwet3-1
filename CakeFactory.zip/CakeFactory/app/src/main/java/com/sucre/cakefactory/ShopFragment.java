package com.sucre.cakefactory;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;

public class ShopFragment extends Fragment {

    private LinearLayout  buildingsContainer, upgradesContainer, achievementsContainer;
    private TabLayout     tabs;
    private View          buildingsScroll, upgradesScroll, achievementsScroll;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_shop, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tabs                 = view.findViewById(R.id.shop_tabs);
        buildingsScroll      = view.findViewById(R.id.scroll_buildings);
        upgradesScroll       = view.findViewById(R.id.scroll_upgrades);
        achievementsScroll   = view.findViewById(R.id.scroll_achievements);
        buildingsContainer   = view.findViewById(R.id.buildings_container);
        upgradesContainer    = view.findViewById(R.id.upgrades_container);
        achievementsContainer= view.findViewById(R.id.achievements_container);

        showPanel(0);

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) { showPanel(tab.getPosition()); }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        renderBuildings();
        renderUpgrades();
        renderAchievements();
    }

    private void showPanel(int pos) {
        buildingsScroll.setVisibility(pos == 0 ? View.VISIBLE : View.GONE);
        upgradesScroll.setVisibility( pos == 1 ? View.VISIBLE : View.GONE);
        achievementsScroll.setVisibility(pos == 2 ? View.VISIBLE : View.GONE);
    }

    // ── BUILDINGS ───────────────────────────────────────────────────
    public void refreshBuildings() {
        if (buildingsContainer == null) return;
        GameState G = GameState.get();
        int count = buildingsContainer.getChildCount();
        for (int i = 0; i < count && i < G.buildings.size(); i++) {
            View card = buildingsContainer.getChildAt(i);
            GameState.Building b = G.buildings.get(i);
            double cost = b.currentCost();
            boolean can = G.cakes >= cost;

            TextView tvCost  = card.findViewById(R.id.tv_bld_cost);
            TextView tvCount = card.findViewById(R.id.tv_bld_count);
            View     btn     = card.findViewById(R.id.btn_buy_bld);

            if (tvCost != null)  tvCost.setText(GameState.fmt(cost) + " 🎂");
            if (tvCount != null) tvCount.setText(String.valueOf(b.count));
            if (btn != null) {
                btn.setEnabled(can);
                btn.setAlpha(can ? 1f : 0.4f);
            }
            card.setBackgroundResource(can ? R.drawable.card_buyable : R.drawable.card_normal);
        }
    }

    private void renderBuildings() {
        buildingsContainer.removeAllViews();
        GameState G = GameState.get();
        LayoutInflater inf = LayoutInflater.from(getContext());
        for (GameState.Building b : G.buildings) {
            View card = inf.inflate(R.layout.item_building, buildingsContainer, false);

            ((TextView) card.findViewById(R.id.tv_bld_icon)).setText(b.icon);
            ((TextView) card.findViewById(R.id.tv_bld_name)).setText(b.name);
            ((TextView) card.findViewById(R.id.tv_bld_desc)).setText(b.desc + " · +" + b.baseCps + "/сек");
            ((TextView) card.findViewById(R.id.tv_bld_cost)).setText(GameState.fmt(b.currentCost()) + " 🎂");
            ((TextView) card.findViewById(R.id.tv_bld_count)).setText(String.valueOf(b.count));

            View btn = card.findViewById(R.id.btn_buy_bld);
            btn.setOnClickListener(v -> {
                boolean ok = G.buyBuilding(b);
                if (ok) {
                    refreshBuildings();
                    ((MainActivity) requireActivity()).showToast("✅ Куплено: " + b.name);
                } else {
                    ((MainActivity) requireActivity()).showToast("❌ Не хватает тортиков!");
                }
            });

            buildingsContainer.addView(card);
        }
    }

    // ── UPGRADES ────────────────────────────────────────────────────
    public void refreshUpgrades() {
        renderUpgrades(); // simpler to re-render upgrades since visibility changes
    }

    private void renderUpgrades() {
        if (upgradesContainer == null) return;
        upgradesContainer.removeAllViews();
        GameState G = GameState.get();
        LayoutInflater inf = LayoutInflater.from(getContext());
        boolean any = false;
        for (GameState.Upgrade u : G.upgrades) {
            if (!G.upgradeConditionMet(u)) continue;
            any = true;
            View card = inf.inflate(R.layout.item_upgrade, upgradesContainer, false);
            boolean can = G.cakes >= u.cost;

            ((TextView) card.findViewById(R.id.tv_upg_icon)).setText(u.icon);
            ((TextView) card.findViewById(R.id.tv_upg_name)).setText(u.name);
            ((TextView) card.findViewById(R.id.tv_upg_desc)).setText(u.desc);
            ((TextView) card.findViewById(R.id.tv_upg_cost)).setText(GameState.fmt(u.cost) + " 🎂");

            card.setBackgroundResource(can ? R.drawable.card_buyable : R.drawable.card_normal);
            card.setOnClickListener(v -> {
                boolean ok = G.buyUpgrade(u);
                if (ok) {
                    renderUpgrades();
                    ((MainActivity) requireActivity()).showToast("✨ " + u.bonus);
                } else {
                    ((MainActivity) requireActivity()).showToast("❌ Не хватает тортиков!");
                }
            });

            upgradesContainer.addView(card);
        }
        if (!any) {
            TextView empty = new TextView(getContext());
            empty.setText("🔒 Покупай постройки, чтобы открыть улучшения");
            empty.setTextSize(14f);
            empty.setPadding(32, 32, 32, 32);
            empty.setTextColor(0xFF9a8478);
            upgradesContainer.addView(empty);
        }
    }

    // ── ACHIEVEMENTS ────────────────────────────────────────────────
    public void refreshAchievements() {
        renderAchievements();
    }

    private void renderAchievements() {
        if (achievementsContainer == null) return;
        achievementsContainer.removeAllViews();
        GameState G = GameState.get();
        LayoutInflater inf = LayoutInflater.from(getContext());
        for (GameState.Achievement a : G.achievements) {
            View card = inf.inflate(R.layout.item_upgrade, achievementsContainer, false);

            ((TextView) card.findViewById(R.id.tv_upg_icon)).setText(a.unlocked ? a.icon : "🔒");
            ((TextView) card.findViewById(R.id.tv_upg_name)).setText(a.name);
            ((TextView) card.findViewById(R.id.tv_upg_desc)).setText(a.desc);
            ((TextView) card.findViewById(R.id.tv_upg_cost)).setText(a.unlocked ? "✓" : "");

            card.setAlpha(a.unlocked ? 1f : 0.45f);
            card.setBackgroundResource(a.unlocked ? R.drawable.card_buyable : R.drawable.card_normal);
            card.setClickable(false);

            achievementsContainer.addView(card);
        }
    }
}
