package com.sucre.cakefactory;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ClickerFragment extends Fragment {

    private TextView tvCakes, tvTotal, tvCps, tvClickPow;
    private TextView tvPresProgress, tvPresLevel;
    private View     presBarFill, presBarWrap;
    private View     btnPrestige;
    private View     cakeBtn;
    private FrameLayout floatContainer;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_clicker, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvCakes       = view.findViewById(R.id.tv_cakes);
        tvTotal       = view.findViewById(R.id.tv_total);
        tvCps         = view.findViewById(R.id.tv_cps);
        tvClickPow    = view.findViewById(R.id.tv_click_pow);
        tvPresProgress= view.findViewById(R.id.tv_pres_progress);
        tvPresLevel   = view.findViewById(R.id.tv_pres_level);
        presBarFill   = view.findViewById(R.id.pres_bar_fill);
        presBarWrap   = view.findViewById(R.id.pres_bar_wrap);
        btnPrestige   = view.findViewById(R.id.btn_prestige);
        cakeBtn       = view.findViewById(R.id.btn_cake);
        floatContainer= view.findViewById(R.id.float_container);

        GameState G = GameState.get();

        // Cake click
        cakeBtn.setOnClickListener(v -> {
            double earned = G.effectiveClickPower();
            G.cakes      += earned;
            G.totalCakes += earned;
            animateCake();
            spawnFloat("+" + GameState.fmt(earned) + "🎂");
            refresh();
        });

        // Prestige
        btnPrestige.setOnClickListener(v -> {
            if (!G.canPrestige()) return;
            G.doPrestige();
            refresh();
            ((MainActivity) requireActivity()).showToast(
                    "👑 Престиж " + G.prestigeLevel + "! Множитель ×" +
                    String.format("%.1f", G.prestigeMult));
        });

        refresh();
    }

    public void refresh() {
        if (getView() == null) return;
        GameState G = GameState.get();

        tvCakes.setText(GameState.fmt(G.cakes) + " 🎂");
        tvTotal.setText(GameState.fmt(G.totalCakes));
        tvCps.setText("в сек: " + GameState.fmt(G.calcCps()));
        tvClickPow.setText("+" + GameState.fmt(G.effectiveClickPower()) + " за клик");

        double pct = Math.min(G.totalCakes / GameState.PRESTIGE_REQ, 1.0);
        tvPresProgress.setText(GameState.fmt(G.totalCakes) + " / 100к 🎂");
        tvPresLevel.setText("Ур. " + G.prestigeLevel);

        // Scale the inner fill view
        if (presBarWrap != null) {
            presBarFill.post(() -> {
                int parentW = presBarWrap.getWidth();
                ViewGroup.LayoutParams lp = presBarFill.getLayoutParams();
                lp.width = (int)(parentW * pct);
                presBarFill.setLayoutParams(lp);
            });
        }

        btnPrestige.setEnabled(G.canPrestige());
        btnPrestige.setAlpha(G.canPrestige() ? 1f : 0.4f);
    }

    private void animateCake() {
        if (cakeBtn == null) return;
        cakeBtn.animate().scaleX(0.82f).scaleY(0.82f).setDuration(60)
               .withEndAction(() ->
                   cakeBtn.animate().scaleX(1f).scaleY(1f).setDuration(120)
                          .setInterpolator(new OvershootInterpolator(3f)).start()
               ).start();
    }

    private void spawnFloat(String text) {
        if (floatContainer == null) return;
        TextView tv = new TextView(getContext());
        tv.setText(text);
        tv.setTextSize(18f);
        tv.setTextColor(0xFFa06a54);

        float x = (float)(Math.random() * 200);
        tv.setX(floatContainer.getWidth() / 2f - 50 + x - 100);
        tv.setY(floatContainer.getHeight() / 2f);

        floatContainer.addView(tv);
        tv.animate().translationYBy(-220f).alpha(0f).setDuration(900)
          .withEndAction(() -> floatContainer.removeView(tv)).start();
    }
}
