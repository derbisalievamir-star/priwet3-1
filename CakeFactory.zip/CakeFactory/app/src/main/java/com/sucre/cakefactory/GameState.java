package com.sucre.cakefactory;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/**
 * Singleton that holds all game state and handles save/load via SharedPreferences.
 */
public class GameState {

    // ── Singleton ──────────────────────────────────────────────────
    private static GameState instance;
    public static GameState get() {
        if (instance == null) instance = new GameState();
        return instance;
    }

    // ── Core numbers ───────────────────────────────────────────────
    public double cakes        = 0;
    public double totalCakes   = 0;
    public double clickPower   = 1;
    public double autoClick    = 0;   // extra cakes/sec from upgrades
    public double prestigeMult = 1.0;
    public int    prestigeLevel = 0;

    // ── Buildings ──────────────────────────────────────────────────
    public static class Building {
        public final String id;
        public final String name;
        public final String icon;
        public final String desc;
        public double baseCps;
        public final double baseCost;
        public final double costMult;
        public int count = 0;

        public Building(String id, String name, String icon, String desc,
                        double baseCps, double baseCost, double costMult) {
            this.id = id; this.name = name; this.icon = icon; this.desc = desc;
            this.baseCps = baseCps; this.baseCost = baseCost; this.costMult = costMult;
        }

        public double currentCost() {
            return Math.floor(baseCost * Math.pow(costMult, count));
        }

        public double totalCps() {
            return baseCps * count;
        }
    }

    // ── Upgrades ───────────────────────────────────────────────────
    public static class Upgrade {
        public final String id;
        public final String name;
        public final String icon;
        public final String desc;
        public final double cost;
        public final String bonus;
        public boolean bought = false;

        // condition type: "always","totalCakes","building"
        public final String condType;
        public final String condBuildingId;
        public final int    condBuildingCount;
        public final double condTotalCakes;

        // effect type: "clickPower","boostBuilding","multAll","autoClick"
        public final String effectType;
        public final String effectBuildingId;
        public final double effectValue;

        public Upgrade(String id, String name, String icon, String desc, double cost, String bonus,
                       String condType, String condBuildingId, int condBuildingCount, double condTotalCakes,
                       String effectType, String effectBuildingId, double effectValue) {
            this.id = id; this.name = name; this.icon = icon; this.desc = desc;
            this.cost = cost; this.bonus = bonus;
            this.condType = condType; this.condBuildingId = condBuildingId;
            this.condBuildingCount = condBuildingCount; this.condTotalCakes = condTotalCakes;
            this.effectType = effectType; this.effectBuildingId = effectBuildingId;
            this.effectValue = effectValue;
        }
    }

    // ── Achievements ───────────────────────────────────────────────
    public static class Achievement {
        public final String id;
        public final String name;
        public final String icon;
        public final String desc;
        public boolean unlocked = false;

        // cond type: "totalCakes","cps","anyBuilding","allBuildings","prestige"
        public final String condType;
        public final double condValue;

        public Achievement(String id, String name, String icon, String desc,
                           String condType, double condValue) {
            this.id = id; this.name = name; this.icon = icon; this.desc = desc;
            this.condType = condType; this.condValue = condValue;
        }
    }

    public List<Building>     buildings    = new ArrayList<>();
    public List<Upgrade>      upgrades     = new ArrayList<>();
    public List<Achievement>  achievements = new ArrayList<>();

    // ── Log ───────────────────────────────────────────────────────
    public List<String> log = new ArrayList<>();

    // ── Listener ──────────────────────────────────────────────────
    public interface OnStateChangedListener {
        void onStateChanged();
    }
    public OnStateChangedListener listener;

    // ── Init ──────────────────────────────────────────────────────
    private GameState() {
        initBuildings();
        initUpgrades();
        initAchievements();
    }

    private void initBuildings() {
        buildings.clear();
        buildings.add(new Building("mixer",   "Миксер",           "🔄", "Замешивает тесто",       0.1,   15,     1.15));
        buildings.add(new Building("oven",    "Печь",             "🔥", "Выпекает коржи",         0.5,   100,    1.15));
        buildings.add(new Building("cream",   "Кремовый цех",     "🍦", "Взбивает кремы",         2,     500,    1.15));
        buildings.add(new Building("decor",   "Мастерская",       "🎨", "Украшает торты",         8,     2000,   1.15));
        buildings.add(new Building("robot",   "Робот-кондитер",   "🤖", "Точность и скорость",    25,    8000,   1.15));
        buildings.add(new Building("factory", "Мини-завод",       "🏭", "Полная линия",           80,    30000,  1.15));
        buildings.add(new Building("portal",  "Портал вкуса",     "🌀", "Торты из другого мира",  250,   100000, 1.15));
    }

    private void initUpgrades() {
        upgrades.clear();
        upgrades.add(new Upgrade("recipe",  "Лучший рецепт",     "📖", "+1 к силе клика",       50,    "🎉 Сила клика +1!",
                "always","",0,0,"clickPower","",1));
        upgrades.add(new Upgrade("knife",   "Острый нож",        "🔪", "Миксеры ×2",            150,   "⚡ Миксеры ×2!",
                "building","mixer",3,0,"boostBuilding","mixer",2));
        upgrades.add(new Upgrade("butter",  "Премиум масло",     "🧈", "Всё производство +20%", 300,   "✨ +20% ко всему!",
                "totalCakes","",0,100,"multAll","",1.2));
        upgrades.add(new Upgrade("spatula", "Золотая лопатка",   "🥄", "+5 к силе клика",       500,   "🏅 Сила клика +5!",
                "totalCakes","",0,300,"clickPower","",5));
        upgrades.add(new Upgrade("turbo",   "Турбо-печь",        "💨", "Печи ×2",               800,   "🔥 Печи ×2!",
                "building","oven",3,0,"boostBuilding","oven",2));
        upgrades.add(new Upgrade("secret",  "Секрет крема",      "🤫", "Кремовый цех ×3",       2500,  "🍦 Цех ×3!",
                "building","cream",3,0,"boostBuilding","cream",3));
        upgrades.add(new Upgrade("frenzy",  "Кликовая лихорадка","⚡", "+20 к силе клика",      4000,  "🌪 Сила клика +20!",
                "totalCakes","",0,2000,"clickPower","",20));
        upgrades.add(new Upgrade("autoclk", "Авто-нажиматель",   "👆", "+5 тортиков/сек",       6000,  "🤖 Авто-клик +5/с!",
                "totalCakes","",0,5000,"autoClick","",5));
        upgrades.add(new Upgrade("choco",   "Шоколадная река",   "🍫", "Заводы ×2",             20000, "🍫 Заводы ×2!",
                "building","factory",2,0,"boostBuilding","factory",2));
        upgrades.add(new Upgrade("legend",  "Легендарный рецепт","📜", "Всё производство ×1.5", 50000, "👑 Производство ×1.5!",
                "totalCakes","",0,30000,"multAll","",1.5));
    }

    private void initAchievements() {
        achievements.clear();
        achievements.add(new Achievement("a1", "Первый торт",     "🎂", "Испеки первый тортик",   "totalCakes", 1));
        achievements.add(new Achievement("a2", "Сотня!",          "💯", "100 тортиков",           "totalCakes", 100));
        achievements.add(new Achievement("a3", "Тысячник",        "🎊", "1 000 тортиков",         "totalCakes", 1000));
        achievements.add(new Achievement("a4", "10к тортиков",    "🍰", "10 000 тортиков",        "totalCakes", 10000));
        achievements.add(new Achievement("a5", "Миллионер",       "💎", "1 000 000 тортиков",     "totalCakes", 1000000));
        achievements.add(new Achievement("a6", "Первая постройка","🏗",  "Купи первую постройку", "anyBuilding", 1));
        achievements.add(new Achievement("a7", "Полный комплект", "🏙",  "Все типы построек",     "allBuildings", 0));
        achievements.add(new Achievement("a8", "Конвейер",        "⚙️", "10 тортиков/сек",       "cps", 10));
        achievements.add(new Achievement("a9", "Фабрика мечты",   "🏭", "100 тортиков/сек",      "cps", 100));
        achievements.add(new Achievement("a10","Перерождение",    "✨", "Первый престиж",         "prestige", 1));
    }

    // ── Computed values ────────────────────────────────────────────
    public double calcCps() {
        double c = 0;
        for (Building b : buildings) c += b.totalCps();
        return (c + autoClick) * prestigeMult;
    }

    public double effectiveClickPower() {
        return clickPower * prestigeMult;
    }

    // ── Upgrade condition check ─────────────────────────────────────
    public boolean upgradeConditionMet(Upgrade u) {
        if (u.bought) return false;
        switch (u.condType) {
            case "always": return true;
            case "totalCakes": return totalCakes >= u.condTotalCakes;
            case "building":
                for (Building b : buildings)
                    if (b.id.equals(u.condBuildingId)) return b.count >= u.condBuildingCount;
                return false;
        }
        return false;
    }

    // ── Apply upgrade ──────────────────────────────────────────────
    public void applyUpgrade(Upgrade u) {
        switch (u.effectType) {
            case "clickPower":
                clickPower += u.effectValue;
                break;
            case "multAll":
                prestigeMult *= u.effectValue;
                break;
            case "autoClick":
                autoClick += u.effectValue;
                break;
            case "boostBuilding":
                for (Building b : buildings)
                    if (b.id.equals(u.effectBuildingId)) { b.baseCps *= u.effectValue; break; }
                break;
        }
    }

    // ── Buy building ───────────────────────────────────────────────
    public boolean buyBuilding(Building b) {
        double cost = b.currentCost();
        if (cakes < cost) return false;
        cakes -= cost;
        b.count++;
        addLog(b.icon + " Куплено: " + b.name + " — " + fmt(cost) + " 🎂");
        return true;
    }

    // ── Buy upgrade ────────────────────────────────────────────────
    public boolean buyUpgrade(Upgrade u) {
        if (cakes < u.cost || u.bought) return false;
        cakes -= u.cost;
        u.bought = true;
        applyUpgrade(u);
        addLog(u.icon + " Улучшение: " + u.name + " — " + u.bonus);
        return true;
    }

    // ── Prestige ───────────────────────────────────────────────────
    public static final double PRESTIGE_REQ = 100_000;

    public boolean canPrestige() { return totalCakes >= PRESTIGE_REQ; }

    public void doPrestige() {
        prestigeLevel++;
        prestigeMult = 1 + prestigeLevel * 0.5;
        cakes = 0; totalCakes = 0; autoClick = 0; clickPower = 1;
        initBuildings();
        for (Upgrade u : upgrades) u.bought = false;
        addLog("👑 Престиж Ур." + prestigeLevel + " — множитель ×" + String.format("%.1f", prestigeMult));
    }

    // ── Check achievements ─────────────────────────────────────────
    /** Returns newly unlocked achievement or null. */
    public Achievement checkAchievements() {
        double cps = calcCps();
        for (Achievement a : achievements) {
            if (a.unlocked) continue;
            boolean ok = false;
            switch (a.condType) {
                case "totalCakes":  ok = totalCakes >= a.condValue; break;
                case "cps":         ok = cps >= a.condValue; break;
                case "prestige":    ok = prestigeLevel >= (int) a.condValue; break;
                case "anyBuilding":
                    for (Building b : buildings) if (b.count > 0) { ok = true; break; }
                    break;
                case "allBuildings":
                    ok = true;
                    for (Building b : buildings) if (b.count == 0) { ok = false; break; }
                    break;
            }
            if (ok) { a.unlocked = true; return a; }
        }
        return null;
    }

    // ── Log ────────────────────────────────────────────────────────
    public void addLog(String msg) {
        log.add(0, msg);
        if (log.size() > 40) log.remove(log.size() - 1);
    }

    // ── Formatting ─────────────────────────────────────────────────
    public static String fmt(double n) {
        if (n >= 1_000_000_000) return String.format("%.1fмлрд", n / 1_000_000_000);
        if (n >= 1_000_000)     return String.format("%.1fмлн",  n / 1_000_000);
        if (n >= 1_000)         return String.format("%.1fк",    n / 1_000);
        return String.valueOf((long) n);
    }

    // ── Save / Load ────────────────────────────────────────────────
    private static final String PREF = "cake_save";

    public void save(Context ctx) {
        SharedPreferences.Editor ed = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit();
        ed.putFloat("cakes",        (float) cakes);
        ed.putFloat("totalCakes",   (float) totalCakes);
        ed.putFloat("clickPower",   (float) clickPower);
        ed.putFloat("autoClick",    (float) autoClick);
        ed.putFloat("prestigeMult", (float) prestigeMult);
        ed.putInt("prestigeLevel",  prestigeLevel);
        for (Building b : buildings) {
            ed.putInt("bld_count_" + b.id, b.count);
            ed.putFloat("bld_cps_" + b.id, (float) b.baseCps);
        }
        for (Upgrade u : upgrades)      ed.putBoolean("upg_" + u.id, u.bought);
        for (Achievement a : achievements) ed.putBoolean("ach_" + a.id, a.unlocked);
        ed.apply();
    }

    public boolean load(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!p.contains("totalCakes")) return false;
        cakes        = p.getFloat("cakes",        0);
        totalCakes   = p.getFloat("totalCakes",   0);
        clickPower   = p.getFloat("clickPower",   1);
        autoClick    = p.getFloat("autoClick",    0);
        prestigeMult = p.getFloat("prestigeMult", 1);
        prestigeLevel = p.getInt("prestigeLevel", 0);
        for (Building b : buildings) {
            b.count   = p.getInt("bld_count_" + b.id, 0);
            b.baseCps = p.getFloat("bld_cps_" + b.id, (float) b.baseCps);
        }
        for (Upgrade u : upgrades)      u.bought   = p.getBoolean("upg_" + u.id, false);
        for (Achievement a : achievements) a.unlocked = p.getBoolean("ach_" + a.id, false);
        return true;
    }
}
