# 🎂 Фабрика Тортов — Android App (Java)

## Как открыть в Android Studio и собрать .apk

### Шаг 1 — Скачай Android Studio
https://developer.android.com/studio  (бесплатно)

### Шаг 2 — Открой проект
1. Запусти Android Studio
2. **File → Open**
3. Выбери папку `CakeFactory` (эту папку целиком)
4. Нажми OK и жди пока Gradle скачает зависимости (~2-5 мин)

### Шаг 3 — Запусти на телефоне или эмуляторе

**На телефоне:**
1. Включи *Режим разработчика* на Android:  
   Настройки → О телефоне → нажми 7 раз на "Номер сборки"
2. Включи *Отладка по USB* в Режиме разработчика
3. Подключи телефон USB-кабелем
4. Нажми ▶ Run в Android Studio — выбери твой телефон

**На эмуляторе (без телефона):**
1. В Android Studio: Tools → Device Manager → Create Device
2. Выбери Pixel 6 → Next → скачай API 34 → Finish
3. Нажми ▶ Run

### Шаг 4 — Получи .apk файл
Build → Build Bundle(s) / APK(s) → Build APK(s)  
Файл появится в: `app/build/outputs/apk/debug/app-debug.apk`

---

## Структура проекта

```
CakeFactory/
├── app/src/main/
│   ├── java/com/sucre/cakefactory/
│   │   ├── GameState.java       ← вся игровая логика + сохранение
│   │   ├── MainActivity.java    ← главный экран, game loop, навигация
│   │   ├── ClickerFragment.java ← экран с тортом
│   │   ├── ShopFragment.java    ← постройки, улучшения, достижения
│   │   └── LogFragment.java     ← история событий
│   ├── res/
│   │   ├── layout/              ← XML разметка экранов
│   │   ├── drawable/            ← иконки и фоны
│   │   ├── values/              ← цвета, строки, темы
│   │   └── menu/                ← нижняя навигация
│   └── AndroidManifest.xml
├── build.gradle
└── settings.gradle
```

## Возможности игры
- 🎂 Нажимай на торт — получай тортики
- 🏗 7 построек (Миксер → Портал вкуса)
- ✨ 10 улучшений с разными эффектами
- 🏆 10 достижений
- 👑 Система престижа (бонус ×1.5 после 100к тортиков)
- 💾 Автосохранение каждые 15 секунд
